import keyword  # 导包, keyword是系统中已经定义好的内容,想要使用就需要导入

print(keyword.kwlist)
