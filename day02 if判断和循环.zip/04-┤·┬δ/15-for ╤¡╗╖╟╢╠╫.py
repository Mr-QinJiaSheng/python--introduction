# 操场跑圈 一共需要跑5圈
for i in range(5):
    print('操场跑圈中')
    # 每跑一圈,需要做3个俯卧撑,
    for j in range(3):
        print('做一个俯卧撑....')
