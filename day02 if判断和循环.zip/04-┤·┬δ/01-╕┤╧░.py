height = 170.5

# 默认本来几位,就显示几位
print(f"我的身高是{height}cm")
# 指定显示2位
print(f"我的身高是{height:.2f}cm")

print(f"我的身高是{height:.3f}cm")
